package alg_hwk6;

public class main {

	public static void main(String[] args) {

		HashMap map = new HashMap();

		
		HashEntry hash1 = new HashEntry(2431342, 5);
		HashEntry hash2 = new HashEntry(2431334, 55);
		HashEntry hash3 = new HashEntry(2532346, 34);
		HashEntry hash4 = new HashEntry(124313421, -1);
		HashEntry hash5 = new HashEntry(6443456, 3);
		HashEntry hash6 = new HashEntry(1235675, 4);

		HashEntry hash7 = new HashEntry(9023423, 14);
		HashEntry hash8 = new HashEntry(8943242, 15);
		HashEntry hash9 = new HashEntry(7823942, 23);
		HashEntry hash10 = new HashEntry(5542094, 22);
		HashEntry hash11 = new HashEntry(6234243, 21);
		HashEntry hash12 = new HashEntry(9845621, 67);

		HashEntry hash13 = new HashEntry(5123567, 66);
		HashEntry hash14 = new HashEntry(2432341, 65);
		HashEntry hash15 = new HashEntry(7584932, 64);
		HashEntry hash16 = new HashEntry(1923441, 63);
		HashEntry hash17 = new HashEntry(4857561, 62);
		HashEntry hash18 = new HashEntry(2343465, 11);

		HashEntry hash19 = new HashEntry(8432793, 10);
		HashEntry hash20 = new HashEntry(2531234, 9);
		HashEntry hash21 = new HashEntry(6542341, 555);
		HashEntry hash22 = new HashEntry(6234211, 535);
		HashEntry hash23 = new HashEntry(9034236, 255);
		HashEntry hash24 = new HashEntry(9834123, 455);

		HashEntry hash25 = new HashEntry(5346634, 955);
		HashEntry hash26 = new HashEntry(2029343, 575);
		HashEntry hash27 = new HashEntry(5234211, 355);
		HashEntry hash28 = new HashEntry(1111111, 215);
		HashEntry hash29 = new HashEntry(3333333, 498);
		HashEntry hash30 = new HashEntry(5555555, 629);

		HashEntry hash31 = new HashEntry(6666666, 100);
		HashEntry hash32 = new HashEntry(7777777, 154);
		HashEntry hash33 = new HashEntry(1212121, 346);
		HashEntry hash34 = new HashEntry(3434343, 651);
		HashEntry hash35 = new HashEntry(4545421, 252);
		HashEntry hash36 = new HashEntry(5656524, 244);

		map.put(2431342, 5);
		map.get(hash1.getKey());
		map.get(4);
		

		
	}

}
