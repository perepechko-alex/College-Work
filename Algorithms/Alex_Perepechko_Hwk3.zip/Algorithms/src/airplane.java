
public class airplane {
    int minStart;
    public airplane(int temp) {
        minStart = temp;
    }
    
    public int getStart() {
        return minStart;
    }
}
